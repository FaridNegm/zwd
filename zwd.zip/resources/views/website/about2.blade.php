@extends('website.app')

@section('title')
    About
@endsection

@section('header')
    {{--header--}}
@endsection

@section('content')


    
@endsection

@section('footer')
    {{--footer--}}
@endsection
