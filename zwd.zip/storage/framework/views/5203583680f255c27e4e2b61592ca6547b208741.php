<?php $__env->startSection('title'); ?>
    All Projects
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <style>
        .pagination {
            display: -ms-flexbox;
            display: flex;
            width: 150px;
            margin: 0 auto;
            -ms-flex-pack: center;
                justify-content: center;
            -ms-flex-align: center;
                align-items: center;
            border: 1px solid #707070;
            border-radius: 30px;
            padding: 10px 20px;
            }

            .pagination li {
            display: inline-block;
            width: auto;
            float: left;
            padding: 0 8px;
            }

            .pagination li a {
            font-family: "Montserrat", sans-serif;
            font-size: 16px;
            font-weight: 300;
            color: #a6a6a6;
            }

            .pagination li a:hover, .pagination li a:focus {
            color: #353535;
            }

            .pagination .active a {
            color: #353535;
            }

            .pagination .pre a, .pagination .nxt a {
            font-weight: 100;
            }

            .pagination2 {
            display: -ms-flexbox;
            display: flex;
            -ms-flex-direction: row;
                flex-direction: row;
            -ms-flex-pack: center;
                justify-content: center;
            -ms-flex-align: center;
                align-items: center;
            }

            .pagination2 a {
            font-size: 22px;
            line-height: 22px;
            padding: 12px 18px;
            border: 1px solid #ddd;
            color: #999;
            }

            .pagination2 .pre {
            border-right: none;
            }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- banner -->
    <section>
        <div class="inner-banner service">
            <img src="<?php echo e(url('website')); ?>/images/banner-services.jpg" alt="banner-image" />
            <div class="container">
                <div class="caption">
                    <h1> ZWD Projects</h1>
                </div>
            </div>
        </div>
    </section>

    <!-- blog  -->
    <section class="blogsection">
      <div class="container">
        <div class="blog-row">

          <header id="header">
            <h2 class="aos-init" data-aos="fade-left" data-aos-duration="1000"> All Projects</h2>
            <div class="aos-init" data-aos="fade-up" data-aos-duration="1500">
              <p>Maecenas quis auctor velit, ac volutpat mi. Mauris at tincidunt tellus. Praesent augue tortor </p>
            </div>
          </header>

          <section>
            <ul class="blog-list">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li>

                <div class="blog-thumbnail">
                  <img src="<?php echo e(url('admin/images/posts/'.$post->image)); ?>" alt="blog" />
                </div>

                <div class="blog-details">

                  <h3><?php echo e($post->title); ?></h3>

                  <div class="adc">
                    <span class="author">John Smith</span>
                    <span class="date">03 February</span>
                    <span class="comment">0 Comments</span>
                  </div>

                  <p><?php echo e(str_limit($post->body , 400)); ?></p>


                  <ul class="blog-social">
                    <li><a href="#"><i class="acro-facebook-logo"></i></a></li>
                    <li><a href="#"><i class="acro-twitter"></i></a></li>
                    <li><a href="#"><i class="acro-behance-logo"></i></a></li>
                  </ul>

                </div>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

                <?php echo e($posts->render()); ?>

          </section>

        </div>
      </div>
    </section>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>