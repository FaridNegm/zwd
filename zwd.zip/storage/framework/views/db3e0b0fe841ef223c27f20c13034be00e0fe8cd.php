<?php $__env->startSection('title'); ?>
    Single Service
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <!-- banner -->
    <section>
    <?php $__currentLoopData = $single_service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="inner-banner event-banner">
        <img src="<?php echo e(url('website')); ?>/images/banner-services.jpg" alt="banner-image" />
        <div class="container">
          <div class="caption">
            <h1><?php echo e($service->title); ?></h1>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>

    <!-- events -->

        <section class="event-page">
            <div class="container">
                <?php $__currentLoopData = $single_service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <header class="header">
                <h2 class="aos-init" data-aos="fade-left" data-aos-duration="1000"> <?php echo e($service->title); ?> </h2>
                <div class="aos-init" data-aos="fade-down" data-aos-duration="1500">
                    <p>Maecenas quis auctor velit, ac volutpat mi. Mauris at tincidunt tellus. Praesent augue tortor, </p>
                </div>
                </header>

                <!-- event-wraper  -->
                <section class="event-wraper2">

                    <!-- event-area | left column 8 -->
                    <div class="event-area2">

                    <!-- single-event box -->
                    <div class="single-event2">

                        <div class="events-thumb aos-init" data-aos="fade-up" data-aos-duration="1500">
                        <img src="<?php echo e(url('admin/images/services/'.$service->image)); ?>" alt="img" style="width:100%;height:350px;"/>

                        </div>

                        <div class="events-dtls">
                        <div class="post-nd aos-init" data-aos="fade-up" data-aos-duration="1800">
                            <span class="clock"><img src="<?php echo e(url('website')); ?>/images/clock.svg" alt="img" /></span>
                            <span class="date"><?php echo e($service->created_at->diffForHumans()); ?></span>
                            <span class="name">Sturard Brought </span>

                            
                        </div>

                        <div class="aos-init" data-aos="fade-up" data-aos-duration="1900">
                            <p><?php echo e($service->body); ?></p>
                        </div>

                        </div>
                    </div>

                    </div>

                    <div class="sidebar">
                    <!-- keyword-search -->
                    <div class="key-search shop-item aos-init" data-aos="fade-up" data-aos-duration="1500">
                        <h3>Search blog</h3>
                        <input placeholder=" " class="input-search2" type="text" required="">
                    </div>

                    <!-- Related Events -->
                    <div class="related-event2">
                        <h3 class="aos-init" data-aos="fade-up" data-aos-duration="1500">Related Services</h3>

                        <ul class="event-list2">
                            <?php $__currentLoopData = $related_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related_service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="aos-init" data-aos="fade-up" data-aos-duration="1300">
                                    <a href="single-blog.html">
                                    <figure>
                                        <img src="<?php echo e(url('admin/images/services/'.$related_service->image)); ?>" alt="img" style="height:45px;"/>
                                    </figure>
                                    <div class="evnt-dtls">
                                        <p><?php echo e(str_limit($related_service->body , 70)); ?></p>
                                        <span class="event-date"><?php echo e($related_service->created_at); ?></span>
                                    </div>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>

                    <!-- calendar -->
                    <!-- <div class="calender-box">
                        <h3 class="aos-init" data-aos="fade-up" data-aos-duration="1500">callender</h3>
                        <div class="calendar aos-init" data-aos="fade-up" data-aos-duration="1300"></div>
                    </div> -->


                    </div>
                </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>